import "./Header.css"
const Header=(props)=>{
return (
    <h1 className="myclass">Employee Management system</h1>
)

}

export default Header;